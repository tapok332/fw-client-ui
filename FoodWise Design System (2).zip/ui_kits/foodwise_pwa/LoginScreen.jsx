// LoginScreen.jsx — onboarding hero + login form. Full-bleed leaf bg decoration.

function LoginScreen({ onLogin, onBack }) {
  const [email, setEmail] = React.useState("");
  const [pwd, setPwd] = React.useState("");
  const [showPwd, setShowPwd] = React.useState(false);

  const steps = [
    { icon: Sprout,   title: "Обирайте", desc: "Знаходьте сюрприз-бокси поблизу зі знижкою 30–70%" },
    { icon: TreePine, title: "Забирайте", desc: "Заберіть замовлення з ресторану чи магазину" },
    { icon: Recycle,  title: "Рятуйте",  desc: "Їжа не потрапляє на смітник, а планета дякує" },
  ];

  return (
    <div style={{
      minHeight: "100%", background: "hsl(var(--background))",
      position: "relative", overflow: "hidden",
    }}>
      {/* Decorative blob */}
      <svg viewBox="0 0 400 400" style={{ position: "absolute", top: -80, right: -120, width: 400, height: 400,
            opacity: 0.05, pointerEvents: "none" }}>
        <path d="M200,20 C280,20 380,100 380,200 C380,300 300,380 200,380 C100,380 20,300 20,200 C20,100 120,20 200,20Z" fill="hsl(var(--primary))"/>
      </svg>
      <svg viewBox="0 0 300 300" style={{ position: "absolute", bottom: 40, left: -80, width: 300, height: 300,
            opacity: 0.04, pointerEvents: "none" }}>
        <path d="M150,10 C150,10 250,80 250,170 C250,260 150,290 150,290 C150,290 50,260 50,170 C50,80 150,10 150,10Z" fill="hsl(var(--primary))"/>
      </svg>

      <div style={{ position: "relative", padding: "32px 24px 40px", display: "flex", flexDirection: "column", gap: 28 }}>

        {/* Language switcher + back */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          {onBack ? (
            <button onClick={onBack} aria-label="Закрити" style={{
              width: 36, height: 36, borderRadius: 9999, border: 0,
              background: "hsl(var(--muted))", color: "hsl(var(--foreground))",
              display: "grid", placeItems: "center", cursor: "pointer",
            }}><X size={18} /></button>
          ) : <div />}
          <div style={{
            display: "inline-flex", alignItems: "center", gap: 4,
            padding: "6px 12px", borderRadius: 9999, background: "hsl(var(--muted))",
            color: "hsl(var(--foreground))", fontSize: 12, fontWeight: 500,
          }}>
            <Globe size={14} /> UK
          </div>
        </div>

        {/* Brand */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, marginTop: 4 }}>
          <div style={{
            width: 64, height: 64, borderRadius: 18, background: "hsl(var(--primary))",
            display: "grid", placeItems: "center", boxShadow: "var(--shadow-cta)",
          }}>
            <Leaf size={32} color="#fff" />
          </div>
          <h1 style={{
            fontFamily: "var(--font-heading)", fontSize: 28, fontWeight: 700,
            margin: 0, color: "hsl(var(--foreground))", textAlign: "center", lineHeight: 1.1,
          }}>
            Рятуйте їжу,<br/>економте гроші
          </h1>
          <p style={{ margin: 0, color: "hsl(var(--muted-foreground))", fontSize: 14, lineHeight: 1.55, textAlign: "center", maxWidth: 290 }}>
            Приєднуйтесь до спільноти свідомих споживачів.
          </p>
        </div>

        {/* How it works */}
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {steps.map((s, i) => {
            const Icon = s.icon;
            return (
              <div key={i} style={{
                display: "flex", alignItems: "center", gap: 14,
                padding: 12, borderRadius: 14,
                background: "hsl(var(--card))", boxShadow: "var(--shadow-soft-sm)",
              }}>
                <div style={{
                  width: 40, height: 40, borderRadius: 12,
                  background: "hsl(var(--primary) / 0.1)",
                  color: "hsl(var(--primary))",
                  display: "grid", placeItems: "center", flexShrink: 0,
                }}>
                  <Icon size={20} />
                </div>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, color: "hsl(var(--foreground))" }}>{s.title}</div>
                  <div style={{ fontSize: 12, color: "hsl(var(--muted-foreground))", marginTop: 1 }}>{s.desc}</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Form */}
        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 4 }}>
          <FwInput
            type="email" placeholder="example@email.com" value={email}
            onChange={e => setEmail(e.target.value)}
            leading={<Mail size={16} />}
          />
          <FwInput
            type={showPwd ? "text" : "password"} placeholder="••••••••" value={pwd}
            onChange={e => setPwd(e.target.value)}
            leading={<Lock size={16} />}
            trailing={
              <button onClick={() => setShowPwd(v => !v)} aria-label="Показати пароль"
                style={{ background: "transparent", border: 0, padding: 6, cursor: "pointer", color: "hsl(var(--muted-foreground))" }}>
                {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            }
          />
          <FwButton fullWidth size="lg" onClick={onLogin}>Увійти</FwButton>

          {/* Divider */}
          <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "8px 0" }}>
            <FwDivider />
            <span style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", letterSpacing: "0.08em" }}>або</span>
            <FwDivider />
          </div>

          {/* OAuth */}
          <FwButton variant="outline" fullWidth size="lg"
            leading={<img src="assets/google-logo.png" alt="" style={{ width: 18, height: 18 }} />}>
            Увійти через Google
          </FwButton>
          <FwButton variant="outline" fullWidth size="lg"
            leading={<img src="assets/telegram-logo.png" alt="" style={{ width: 18, height: 18 }} />}>
            Увійти через Telegram
          </FwButton>

          <div style={{ textAlign: "center", marginTop: 8, fontSize: 13, color: "hsl(var(--muted-foreground))" }}>
            Немає облікового запису? <a href="#" style={{ color: "hsl(var(--primary))", textDecoration: "none", fontWeight: 500 }}>Зареєструватися</a>
          </div>
        </div>
      </div>
    </div>
  );
}

window.LoginScreen = LoginScreen;
