// FlyToCart.jsx — flies a small product image from a source point to a target
// (the cart icon). Caller emits the source rect; the cart-target ref is found
// by the [data-cart-target] attribute on the cart tab icon at fire-time.
// Lightweight: no framer-motion, uses Web Animations API.

function FlyToCart({ trigger, image, source, onArrive }) {
  const ref = React.useRef(null);

  React.useEffect(() => {
    if (!trigger || !source) return;
    const target = document.querySelector("[data-cart-target]");
    if (!target) { onArrive && onArrive(); return; }
    const tr = target.getBoundingClientRect();
    const dest = { x: tr.left + tr.width / 2, y: tr.top + tr.height / 2 };

    const el = ref.current;
    if (!el) return;

    const dx = dest.x - source.x;
    const dy = dest.y - source.y;

    el.style.left = (source.x - 28) + "px";
    el.style.top  = (source.y - 28) + "px";
    el.style.display = "block";

    const anim = el.animate(
      [
        { transform: "translate(0,0) scale(1)",                opacity: 1, offset: 0 },
        { transform: `translate(${dx * 0.5}px, ${dy * 0.4 - 80}px) scale(0.9)`, opacity: 1, offset: 0.6 },
        { transform: `translate(${dx}px, ${dy}px) scale(0.25)`, opacity: 0.7, offset: 1 },
      ],
      { duration: 700, easing: "cubic-bezier(.5,0,.6,1)", fill: "forwards" }
    );
    anim.onfinish = () => {
      el.style.display = "none";
      onArrive && onArrive();
    };
    return () => anim.cancel();
  }, [trigger]);

  if (!source) return null;
  return (
    <div ref={ref} style={{
      position: "fixed", zIndex: 9999, display: "none", pointerEvents: "none",
      width: 56, height: 56, borderRadius: 14, overflow: "hidden",
      background: `#fff url(${image}) center/cover`,
      boxShadow: "0 10px 30px rgba(30,60,30,0.35), 0 0 0 3px #fff",
    }} />
  );
}

window.FlyToCart = FlyToCart;
