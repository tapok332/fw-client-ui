# FoodWise PWA — UI kit

A pixel-close, click-thru recreation of the **FoodWise consumer PWA** (the
mobile-web app at `fw-client-ui-new/`). Open `index.html` and you get a single
iPhone-framed prototype where you can:

- Browse the **home screen** — hero carousel, category chips, featured stores,
  surprise-box rail, nearby stores.
- Tap any store card to land on the **store detail screen** with its boxes.
- Tap the **+** on any surprise box to add it to your cart.
- Open the **cart** (tab bar or header), increment / decrement / remove items,
  see the eco-savings block, hit the checkout CTA.
- Tap the profile avatar to open the **login + onboarding screen** with full
  email / OAuth form and the three-step "Choose · Pick up · Save" rail.

It's purely client-side; no real API, no real auth. State lives in React
state — refreshing resets it.

---

## Files

| File              | Purpose                                                                |
| ----------------- | ---------------------------------------------------------------------- |
| `index.html`      | Loads React + Babel + every component. Mounts the prototype in `#root`. |
| `colors_and_type.css` | Design tokens (copy of root file).                                 |
| `ios-frame.jsx`   | iPhone bezel + status bar + home indicator (starter component).        |
| `Icons.jsx`       | Inline Lucide-style SVG icons (`<Leaf>`, `<Cart>`, `<MapPin>`, …).     |
| `Primitives.jsx`  | `FwButton`, `FwIconButton`, `FwBadge`, `FwInput`, `FwGlassChip`, `FwDivider`. |
| `Chrome.jsx`      | `FwBrandMark`, `FwHeader` (floating glass top bar), `FwTabBar` (mobile bottom nav), `FwSectionHeader`. |
| `Cards.jsx`       | `FwCard`, `FwCategoryChip`, `FwStoreCard`, `FwSurpriseBoxCard`, `FwHeroSlide`, `FwCartLine`. |
| `Data.jsx`        | Mock stores, boxes, hero slides, categories. Ukrainian copy.           |
| `HomeScreen.jsx`  | Home view — hero carousel + category chips + 3 card rails.             |
| `StoreScreen.jsx` | Store detail — photo header, info card, pickup/delivery tabs, box list. |
| `CartScreen.jsx`  | Cart + empty state + eco-storytelling block + totals + CTA.            |
| `LoginScreen.jsx` | Onboarding hero + email / Google / Telegram form.                      |
| `App.jsx`         | Route state, cart state, wiring between screens.                       |
| `assets/`         | Photos + payment marks (copied from the design-system root).           |

---

## Component conventions

- All public components are prefixed `Fw…` and exported to `window` (multi-script
  Babel quirk — each `<script type="text/babel">` gets its own scope).
- Inline `style={{}}` is used throughout instead of class-based CSS — the design
  tokens come in via `hsl(var(--…))`. Easier to read and direct-edit, no
  framework needed.
- Icons are inline SVGs that accept a `size`, `color`, and `strokeWidth` prop.
  Matches the Lucide React API.
- Photos are hot-linked from Unsplash CDN. Replace `Data.jsx::PHOTOS` with your
  own URLs for production.

---

## What's intentionally NOT here

- **No real auth, no real cart sync, no real Google Maps.** This is a UI kit.
- **No favorites, restaurants, or stores tab content.** The codebase has full
  flows for these but they would duplicate patterns already covered by Home and
  Store. Tabs just route back to Home for the demo.
- **No checkout flow / payment screens.** Checkout button is a `confirm()`
  placeholder. Add a checkout screen using the same primitives if you need it.

---

## Adding to this kit

If you need a new screen, follow the existing pattern:

1. Create `MyScreen.jsx` that defines `function MyScreen({ ...props })` and
   ends with `window.MyScreen = MyScreen;`.
2. Add `<script type="text/babel" src="MyScreen.jsx"></script>` to `index.html`
   BEFORE `App.jsx`.
3. Add the route to `App.jsx`'s `route` switch and a tab in `FwTabBar` if
   relevant.
