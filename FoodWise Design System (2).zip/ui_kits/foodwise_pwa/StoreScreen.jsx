// StoreScreen.jsx — single store detail. Photo header w/ back button, store info,
// pickup/delivery tabs, list of surprise boxes from this store.

function StoreScreen({ store, onBack, onAddToCart, cartCount, onCart }) {
  const [tab, setTab] = React.useState("pickup");
  const storeBoxes = BOXES.filter(b => b.storeId === store.id);
  const showBoxes = storeBoxes.length > 0 ? storeBoxes : BOXES.slice(0, 3);

  return (
    <div style={{ paddingBottom: 110, background: "hsl(var(--background))", minHeight: "100%" }}>
      {/* Photo header */}
      <div style={{ position: "relative", height: 240, background: `url(${store.image}) center/cover` }}>
        <div style={{ position: "absolute", inset: 0,
                      background: "linear-gradient(to bottom, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0) 50%, rgba(0,0,0,0.45) 100%)" }} />
        <div style={{ position: "absolute", top: 16, left: 16, right: 16, display: "flex", justifyContent: "space-between" }}>
          <button onClick={onBack} aria-label="Назад" style={{
            width: 40, height: 40, borderRadius: 9999, border: 0,
            background: "rgba(255,255,255,0.92)", backdropFilter: "blur(8px)",
            color: "hsl(var(--foreground))", display: "grid", placeItems: "center", cursor: "pointer",
            boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
          }}><ChevLeft size={22} /></button>
          <div style={{ display: "flex", gap: 8 }}>
            <button aria-label="В обране" style={{
              width: 40, height: 40, borderRadius: 9999, border: 0,
              background: "rgba(255,255,255,0.92)", backdropFilter: "blur(8px)",
              color: "hsl(var(--foreground))", display: "grid", placeItems: "center", cursor: "pointer",
              boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
            }}><Heart size={20} /></button>
            <button onClick={onCart} aria-label="Кошик" style={{
              width: 40, height: 40, borderRadius: 9999, border: 0,
              background: "rgba(255,255,255,0.92)", backdropFilter: "blur(8px)",
              color: "hsl(var(--foreground))", display: "grid", placeItems: "center", cursor: "pointer",
              boxShadow: "0 2px 8px rgba(0,0,0,0.15)", position: "relative",
            }}>
              <Cart size={20} />
              {cartCount > 0 && (
                <span style={{
                  position: "absolute", top: 2, right: 2,
                  background: "hsl(var(--primary))", color: "#fff",
                  fontSize: 9, fontWeight: 700, lineHeight: 1,
                  minWidth: 16, height: 16, borderRadius: 9999,
                  display: "grid", placeItems: "center",
                }}>{cartCount}</span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Info card */}
      <div style={{ padding: "0 16px", marginTop: -32, position: "relative", zIndex: 2 }}>
        <div style={{
          background: "hsl(var(--card))", borderRadius: 18, padding: 18,
          boxShadow: "var(--shadow-soft-md)",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 14 }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <h1 style={{ fontFamily: "var(--font-heading)", fontSize: 24, fontWeight: 700,
                           margin: 0, color: "hsl(var(--foreground))", lineHeight: 1.1 }}>
                {store.name}
              </h1>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6, color: "hsl(var(--muted-foreground))", fontSize: 13 }}>
                <MapPin size={14} color="hsl(var(--primary) / 0.7)" />
                <span>{store.address}</span>
              </div>
            </div>
            <div style={{
              display: "flex", alignItems: "center", gap: 4,
              padding: "6px 11px", borderRadius: 9999,
              background: "hsla(45,95%,55%,0.12)",
              color: "hsl(35 80% 35%)", fontSize: 13, fontWeight: 600,
            }}>
              <Star size={14} color="hsl(45 95% 55%)" style={{ fill: "hsl(45 95% 55%)" }} />
              {store.rating.toFixed(1)}
            </div>
          </div>

          <div style={{
            display: "flex", gap: 8, marginTop: 14, paddingTop: 14,
            borderTop: "1px solid hsl(var(--border))",
            fontSize: 12, color: "hsl(var(--muted-foreground))",
            fontVariantNumeric: "tabular-nums",
          }}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
              <Clock size={13} color="hsl(var(--primary) / 0.7)" /> Відчинено · до 22:00
            </span>
            <span>·</span>
            <span>0.8 км</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ padding: "20px 16px 0" }}>
        <div style={{ display: "inline-flex", padding: 4, background: "hsl(var(--secondary))", borderRadius: 14 }}>
          {[["pickup","Самовивіз"],["delivery","Доставка"]].map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)}
              style={{
                padding: "8px 16px", border: 0, borderRadius: 10,
                background: tab === id ? "hsl(var(--card))" : "transparent",
                color: tab === id ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground))",
                fontWeight: 500, fontSize: 13, cursor: "pointer",
                boxShadow: tab === id ? "var(--shadow-soft-sm)" : "none",
                transition: "all 200ms ease",
              }}>{label}</button>
          ))}
        </div>
      </div>

      {/* Boxes list */}
      <section style={{ padding: "16px 16px 0" }}>
        <h2 style={{
          fontFamily: "var(--font-heading)", fontSize: 18, fontWeight: 600,
          color: "hsl(var(--foreground))", margin: "8px 0 12px",
          display: "flex", alignItems: "center", gap: 10,
        }}>
          <span style={{ display: "inline-block", width: 4, height: 18, borderRadius: 2, background: "hsl(var(--primary))" }} />
          Доступні бокси
        </h2>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {showBoxes.map(box => (
            <div key={box.id} style={{
              display: "flex", gap: 12, padding: 12,
              background: "hsl(var(--card))", borderRadius: 16,
              boxShadow: "var(--shadow-soft-sm)",
            }}>
              <div style={{ width: 76, height: 76, borderRadius: 12, background: `url(${box.image}) center/cover`, flexShrink: 0, position: "relative" }}>
                <span style={{
                  position: "absolute", top: 4, left: 4,
                  background: "hsl(var(--accent))", color: "#fff",
                  padding: "2px 7px", borderRadius: 9999,
                  fontSize: 9, fontWeight: 700,
                }}>-{box.discount}%</span>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600, fontSize: 14, color: "hsl(var(--foreground))" }}>{box.name}</div>
                <div style={{ display: "flex", gap: 8, fontSize: 11, color: "hsl(var(--muted-foreground))", marginTop: 3,
                              fontVariantNumeric: "tabular-nums" }}>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>
                    <Clock size={12} color="hsl(var(--primary) / 0.7)" /> {box.pickupWindow}
                  </span>
                </div>
                <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginTop: 8 }}>
                  <div style={{ display: "flex", alignItems: "baseline", gap: 6, fontVariantNumeric: "tabular-nums" }}>
                    <span style={{ fontFamily: "var(--font-heading)", fontWeight: 700, fontSize: 17, color: "hsl(var(--primary))" }}>{box.price} ₴</span>
                    <span style={{ fontSize: 12, color: "hsl(var(--muted-foreground))", textDecoration: "line-through" }}>{box.retailPrice} ₴</span>
                  </div>
                  <button onClick={(e) => {
                    const r = e.currentTarget.getBoundingClientRect();
                    onAddToCart && onAddToCart(box, { x: r.left + r.width / 2, y: r.top + r.height / 2 });
                  }} style={{
                    width: 36, height: 36, borderRadius: 9999, border: 0,
                    background: "hsl(var(--primary))", color: "#fff",
                    display: "grid", placeItems: "center", cursor: "pointer",
                    boxShadow: "0 2px 8px hsla(145,63%,30%,0.4)",
                  }}><Plus size={18} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

window.StoreScreen = StoreScreen;
