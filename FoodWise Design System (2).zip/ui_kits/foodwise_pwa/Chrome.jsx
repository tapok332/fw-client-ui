// Chrome.jsx — top floating glass header + bottom tab nav. Mobile.

const FwBrandMark = ({ size = 22 }) => (
  <div style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
    <Leaf size={size} color="hsl(var(--primary))" />
    <span style={{
      fontFamily: "var(--font-heading)", fontWeight: 700,
      fontSize: size * 0.9, color: "hsl(var(--foreground))",
      letterSpacing: "-0.01em",
    }}>FoodWise</span>
  </div>
);

// Floating glass header — sticky top, mx-4 mt-3 rounded-2xl
const FwHeader = ({ cartCount = 0, onCart, onProfile, onSearch }) => (
  <div style={{
    margin: "12px 16px 0",
    padding: "12px 18px",
    borderRadius: 18,
    background: "rgba(251,249,246,0.85)",
    backdropFilter: "blur(12px) saturate(150%)",
    WebkitBackdropFilter: "blur(12px) saturate(150%)",
    boxShadow: "0 4px 24px rgba(30,60,30,0.08)",
    display: "flex", justifyContent: "space-between", alignItems: "center",
    position: "sticky", top: 12, zIndex: 50,
  }}>
    <FwBrandMark size={22} />
    <div style={{ display: "flex", gap: 2 }}>
      <FwIconButton ariaLabel="Search" onClick={onSearch}><Search size={20} /></FwIconButton>
      <FwIconButton ariaLabel="Cart" onClick={onCart} style={{ position: "relative" }}>
        <Cart size={20} />
        {cartCount > 0 && (
          <span style={{
            position: "absolute", top: 2, right: 2,
            background: "hsl(var(--primary))", color: "#fff",
            fontSize: 10, fontWeight: 600, lineHeight: 1,
            minWidth: 18, height: 18, borderRadius: 9999,
            display: "grid", placeItems: "center",
            boxShadow: "var(--shadow-soft-sm)",
          }}>{cartCount > 99 ? "99+" : cartCount}</span>
        )}
      </FwIconButton>
      <FwIconButton ariaLabel="Profile" onClick={onProfile}>
        <div style={{
          width: 28, height: 28, borderRadius: 9999,
          background: "hsl(var(--muted))",
          display: "grid", placeItems: "center",
        }}>
          <User size={14} />
        </div>
      </FwIconButton>
    </div>
  </div>
);

// Mobile bottom nav — 6 tabs
const FwTabBar = ({ active = "home", onChange, cartCount = 0 }) => {
  const tabs = [
    { id: "home",        icon: Home,     label: "Дім" },
    { id: "restaurants", icon: Utensils, label: "Ресторани" },
    { id: "stores",      icon: Store,    label: "Магазини" },
    { id: "favorites",   icon: Heart,    label: "Обране" },
    { id: "cart",        icon: Cart,     label: "Кошик" },
    { id: "profile",     icon: User,     label: "Профіль" },
  ];
  return (
    <nav style={{
      position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 40,
      background: "rgba(255,255,255,0.92)",
      backdropFilter: "blur(12px)",
      WebkitBackdropFilter: "blur(12px)",
      boxShadow: "var(--shadow-nav-top)",
      display: "flex", justifyContent: "space-around",
      padding: "8px 6px 24px",
    }}>
      {tabs.map(tab => {
        const Icon = tab.icon;
        const isActive = active === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onChange && onChange(tab.id)}
            style={{
              display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
              padding: "4px 2px", border: 0, background: "transparent",
              cursor: "pointer", position: "relative",
              color: isActive ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))",
              transition: "color 200ms ease",
            }}
          >
            <div data-cart-target={tab.id === "cart" ? "true" : undefined} style={{
              position: "relative", width: 36, height: 36, borderRadius: 12,
              display: "grid", placeItems: "center",
              background: isActive ? "hsl(var(--primary) / 0.1)" : "transparent",
              transition: "background 200ms ease",
              animation: tab.id === "cart" && cartCount > 0 ? "fwCartBump 380ms cubic-bezier(.23,1,.32,1)" : undefined,
            }}
            key={`cart-${cartCount}`}>
              <Icon size={20} />
              {tab.id === "cart" && cartCount > 0 && (
                <span style={{
                  position: "absolute", top: 0, right: 0,
                  background: "hsl(var(--primary))", color: "#fff",
                  fontSize: 9, fontWeight: 700, lineHeight: 1,
                  minWidth: 16, height: 16, borderRadius: 9999, padding: "0 3px",
                  display: "grid", placeItems: "center",
                  boxShadow: "var(--shadow-soft-sm)",
                }}>{cartCount > 99 ? "99+" : cartCount}</span>
              )}
            </div>
            <span style={{
              fontSize: 10, fontFamily: "var(--font-body)",
              fontWeight: isActive ? 500 : 400,
            }}>{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};

// Section header — has an accent bar + title + optional 'all' link
const FwSectionHeader = ({ title, allLabel = "Усі", onAll }) => (
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 20px", marginBottom: 12 }}>
    <h2 style={{
      fontFamily: "var(--font-heading)", fontWeight: 600, fontSize: 22,
      color: "hsl(var(--foreground))", display: "flex", alignItems: "center", gap: 10, margin: 0,
    }}>
      <span style={{ display: "inline-block", width: 4, height: 22, borderRadius: 2, background: "hsl(var(--primary))" }} />
      {title}
    </h2>
    {onAll && (
      <button onClick={onAll} style={{ background: "transparent", border: 0, color: "hsl(var(--primary))", fontSize: 14, fontFamily: "var(--font-body)", fontWeight: 500, cursor: "pointer" }}>
        {allLabel}
      </button>
    )}
  </div>
);

Object.assign(window, { FwBrandMark, FwHeader, FwTabBar, FwSectionHeader });
