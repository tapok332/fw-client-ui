// Primitives.jsx — buttons, badges, inputs, glass chips. Match shadcn/ui styles.

const FwButton = ({
  variant = "default", size = "default", children, leading, trailing,
  fullWidth = false, onClick, disabled, style = {}, ariaLabel,
}) => {
  const base = {
    display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8,
    fontFamily: "var(--font-body)", fontWeight: 500, whiteSpace: "nowrap",
    border: 0, cursor: disabled ? "not-allowed" : "pointer",
    transition: "background-color 200ms ease, transform 120ms ease, box-shadow 200ms ease",
    opacity: disabled ? 0.5 : 1,
    width: fullWidth ? "100%" : "auto",
  };
  const sizes = {
    sm:      { height: 36, padding: "0 14px", fontSize: 13, borderRadius: 10 },
    default: { height: 44, padding: "0 18px", fontSize: 14, borderRadius: 12 },
    lg:      { height: 50, padding: "0 24px", fontSize: 16, borderRadius: 14 },
    xl:      { height: 56, padding: "0 28px", fontSize: 16, borderRadius: 16 },
  };
  const variants = {
    default:     { background: "hsl(var(--primary))", color: "#fff", boxShadow: "var(--shadow-cta)" },
    secondary:   { background: "hsl(var(--secondary))", color: "hsl(var(--secondary-foreground))" },
    outline:     { background: "transparent", color: "hsl(var(--foreground))", border: "1px solid hsl(var(--border))" },
    ghost:       { background: "transparent", color: "hsl(var(--foreground))" },
    link:        { background: "transparent", color: "hsl(var(--primary))", padding: 0, height: "auto", textDecoration: "underline", textUnderlineOffset: 3 },
    destructive: { background: "hsl(var(--destructive))", color: "#fff" },
    glass:       { background: "rgba(255,255,255,0.92)", color: "hsl(var(--foreground))", backdropFilter: "blur(8px)", boxShadow: "var(--shadow-soft-sm)" },
  };
  return (
    <button
      onClick={onClick} disabled={disabled} aria-label={ariaLabel}
      style={{ ...base, ...sizes[size], ...variants[variant], ...style }}
    >
      {leading}
      {children}
      {trailing}
    </button>
  );
};

const FwIconButton = ({ children, onClick, ariaLabel, active = false, size = 40, style = {} }) => (
  <button
    onClick={onClick} aria-label={ariaLabel}
    style={{
      width: size, height: size, borderRadius: 12, border: 0,
      background: active ? "hsl(var(--primary) / 0.1)" : "transparent",
      color: active ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))",
      display: "grid", placeItems: "center", cursor: "pointer",
      transition: "background-color 200ms ease, color 200ms ease",
      ...style,
    }}
  >
    {children}
  </button>
);

const FwBadge = ({ variant = "default", children, style = {} }) => {
  const variants = {
    default:     { background: "hsl(var(--primary))", color: "#fff" },
    secondary:   { background: "hsl(var(--secondary))", color: "hsl(var(--secondary-foreground))" },
    accent:      { background: "hsl(var(--accent))", color: "#fff" },
    outline:     { background: "transparent", color: "hsl(var(--foreground))", border: "1px solid hsl(var(--border))" },
    destructive: { background: "hsl(var(--destructive))", color: "#fff" },
  };
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", padding: "4px 10px", borderRadius: 9999,
      fontSize: 11, fontWeight: 600, lineHeight: 1, letterSpacing: 0,
      ...variants[variant], ...style,
    }}>
      {children}
    </span>
  );
};

const FwInput = ({ leading, trailing, error, ...rest }) => (
  <div style={{ position: "relative", display: "flex", alignItems: "center" }}>
    {leading && (
      <span style={{ position: "absolute", left: 14, display: "flex", color: "hsl(var(--muted-foreground))", pointerEvents: "none" }}>
        {leading}
      </span>
    )}
    <input
      {...rest}
      style={{
        height: 44, width: "100%",
        padding: `0 ${trailing ? 44 : 14}px 0 ${leading ? 42 : 14}px`,
        borderRadius: 10,
        border: error ? "1px solid hsl(var(--destructive))" : "1px solid hsl(var(--border))",
        background: "hsl(var(--card))",
        fontFamily: "var(--font-body)", fontSize: 15,
        color: "hsl(var(--foreground))",
        outline: "none",
        transition: "border-color 200ms ease, box-shadow 200ms ease",
        boxSizing: "border-box",
        ...rest.style,
      }}
      onFocus={e => { e.target.style.borderColor = "hsl(var(--primary))"; e.target.style.boxShadow = "0 0 0 3px hsl(var(--primary) / 0.15)"; rest.onFocus && rest.onFocus(e); }}
      onBlur={e => { e.target.style.borderColor = error ? "hsl(var(--destructive))" : "hsl(var(--border))"; e.target.style.boxShadow = "none"; rest.onBlur && rest.onBlur(e); }}
    />
    {trailing && (
      <span style={{ position: "absolute", right: 12, display: "flex", color: "hsl(var(--muted-foreground))" }}>
        {trailing}
      </span>
    )}
  </div>
);

// Glass pill — used on photos for ratings, discount overlays, etc.
const FwGlassChip = ({ children, style = {} }) => (
  <div style={{
    display: "inline-flex", alignItems: "center", gap: 4,
    background: "rgba(255,255,255,0.92)", backdropFilter: "blur(8px)",
    color: "hsl(var(--foreground))",
    padding: "5px 10px", borderRadius: 9999,
    fontSize: 11, fontWeight: 600,
    boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
    ...style,
  }}>
    {children}
  </div>
);

const FwDivider = ({ vertical = false, style = {} }) => (
  <div style={{
    background: "hsl(var(--border))",
    ...(vertical ? { width: 1, alignSelf: "stretch" } : { height: 1, width: "100%" }),
    ...style,
  }} />
);

Object.assign(window, { FwButton, FwIconButton, FwBadge, FwInput, FwGlassChip, FwDivider });
