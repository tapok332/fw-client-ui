// Icons.jsx — Lucide-style inline SVG icons (stroke icons, 24x24 viewBox).
// Reproduced from lucide.dev (MIT). Pass size + className.

const I = ({ d, size = 20, color = "currentColor", strokeWidth = 2, ...rest }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
       stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
       style={{ flexShrink: 0, ...rest.style }} {...rest}>
    {Array.isArray(d) ? d.map((path, i) => <path key={i} d={path} />) : <path d={d} />}
  </svg>
);

const Leaf      = (p) => <I {...p} d={["M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19.2 2.96a1 1 0 0 1 1.8.4 28.3 28.3 0 0 1-3.2 14.06A7 7 0 0 1 11 20Z","M2 21c0-3 1.85-5.36 5.08-6"]} />;
const Search    = (p) => <I {...p} d={["M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z","m21 21-4.35-4.35"]} />;
const Cart      = (p) => <I {...p} d={["M3 3h2l2.4 12.5a2 2 0 0 0 2 1.5h9.5a2 2 0 0 0 2-1.5L22 6H6","M9 21a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z","M20 21a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"]} />;
const Heart     = (p) => <I {...p} d={["M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"]} />;
const MapPin    = (p) => <I {...p} d={["M20 10c0 7-8 12-8 12s-8-5-8-12a8 8 0 0 1 16 0Z","M12 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"]} />;
const Clock     = (p) => <I {...p} d={["M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20Z","M12 6v6l4 2"]} />;
const Star      = (p) => <I {...p} d={["M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"]} />;
const User      = (p) => <I {...p} d={["M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2","M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z"]} />;
const Home      = (p) => <I {...p} d={["m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z","M9 22V12h6v10"]} />;
const Utensils  = (p) => <I {...p} d={["M3 2v7c0 1.1.9 2 2 2h2v11","M7 2v20","M21 15V2c-2.21 0-4 1.79-4 4v6c0 1.1.9 2 2 2zM17 22v-7"]} />;
const Store     = (p) => <I {...p} d={["M2 7l1.5-5h17L22 7v3H2zM4 10h16v11H4z","M9 21v-6h6v6"]} />;
const Plus      = (p) => <I {...p} d={["M12 5v14","M5 12h14"]} />;
const Minus     = (p) => <I {...p} d={["M5 12h14"]} />;
const Trash     = (p) => <I {...p} d={["M3 6h18","m19 6-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6","M10 11v6","M14 11v6","M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"]} />;
const Check     = (p) => <I {...p} d={["M20 6 9 17l-5-5"]} />;
const X         = (p) => <I {...p} d={["M18 6 6 18","m6 6 12 12"]} />;
const ChevLeft  = (p) => <I {...p} d={["m15 18-6-6 6-6"]} />;
const ChevRight = (p) => <I {...p} d={["m9 18 6-6-6-6"]} />;
const Sprout    = (p) => <I {...p} d={["M7 20h10","M10 20c5.5-2.5.8-6.4 3-10","M9.5 9.4c1.16.7 2.05 1.79 2.55 3.1.46-1.75 1.55-3.16 3-4.07.65-.42 1.5-.57 2.45-.57 1 0 1.95.32 2.5 1-2.5.59-3.45 2.74-3.45 4.04 0 .57.27 1.07.27 1.07-2.34 0-3.7.05-4.32.32"]} />;
const TreePine  = (p) => <I {...p} d={["M17 14v.8a2 2 0 0 0 .92 1.7L23 20H1l5.08-3.5a2 2 0 0 0 .92-1.7V14","M5 14h14L13 5a1.7 1.7 0 0 0-2.4 0L5 14Z","M9 22v-4h6v4"]} />;
const Recycle   = (p) => <I {...p} d={["M7 19l-3-3 3-3","M17 5l3 3-3 3","M14 16l-4 4M10 8l4-4","M14 4l-1 2M10 20l1-2"]} />;
const Eye       = (p) => <I {...p} d={["M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z","M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"]} />;
const EyeOff    = (p) => <I {...p} d={["M10 4.27A11 11 0 0 1 22 12s-3 7-10 7c-1.5 0-2.9-.3-4.13-.81","M1 1l22 22","M9.4 9.4a3 3 0 0 0 4.2 4.2"]} />;
const Globe     = (p) => <I {...p} d={["M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20Z","M2 12h20","M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20Z"]} />;
const Mail      = (p) => <I {...p} d={["M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z","m22 6-10 7L2 6"]} />;
const Lock      = (p) => <I {...p} d={["M5 11h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2z","M7 11V7a5 5 0 0 1 10 0v4"]} />;
const Bell      = (p) => <I {...p} d={["M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9","M10.3 21a1.94 1.94 0 0 0 3.4 0"]} />;
const ShoppingBag = (p) => <I {...p} d={["M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z","M3 6h18","M16 10a4 4 0 0 1-8 0"]} />;

Object.assign(window, {
  IconI: I, Leaf, Search, Cart, Heart, MapPin, Clock, Star, User, Home, Utensils, Store,
  Plus, Minus, Trash, Check, X, ChevLeft, ChevRight, Sprout, TreePine, Recycle,
  Eye, EyeOff, Globe, Mail, Lock, Bell, ShoppingBag,
});
