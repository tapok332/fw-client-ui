// App.jsx — orchestrates screens, manages cart + nav state. Renders inside <IOSDevice>.

function App() {
  // routes: 'home' | 'restaurants' | 'stores' | 'favorites' | 'cart' | 'profile' | 'login' | 'store-detail'
  const [route, setRoute] = React.useState("home");
  const [storeStack, setStoreStack] = React.useState([]); // most recent on top
  const [cart, setCart] = React.useState([]);

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  // Fly-to-cart state — incremented each time, used as React `key` to retrigger the animation
  const [flyTick, setFlyTick] = React.useState(0);
  const [flyState, setFlyState] = React.useState({ image: null, source: null });

  const addToCart = (box, source) => {
    // Fire flying-image animation first, then commit cart change on arrival.
    if (source) {
      setFlyState({ image: box.image, source });
      setFlyTick(t => t + 1);
    }
    // commit immediately so the cart count bumps in sync with the icon
    setCart(c => {
      const existing = c.find(i => i.id === box.id);
      if (existing) return c.map(i => i.id === box.id ? { ...i, qty: i.qty + 1 } : i);
      return [...c, { ...box, qty: 1 }];
    });
  };

  const onTab = (tab) => setRoute(tab);
  const onOpenStore = (store) => { setStoreStack([store]); setRoute("store-detail"); };
  const onCart = () => setRoute("cart");
  const onProfile = () => setRoute("login");

  let screen;
  if (route === "store-detail") {
    const store = storeStack[0] || STORES[0];
    screen = <StoreScreen
      store={store}
      onBack={() => { setStoreStack([]); setRoute("home"); }}
      onAddToCart={addToCart}
      cartCount={cartCount}
      onCart={onCart}
    />;
  } else if (route === "cart") {
    screen = <CartScreen
      items={cart}
      onBack={() => setRoute("home")}
      onInc={id => setCart(c => c.map(i => i.id === id ? { ...i, qty: i.qty + 1 } : i))}
      onDec={id => setCart(c => c.map(i => i.id === id ? { ...i, qty: Math.max(0, i.qty - 1) } : i).filter(i => i.qty > 0))}
      onRemove={id => setCart(c => c.filter(i => i.id !== id))}
      onCheckout={() => alert("Checkout (demo)")}
      onExplore={() => setRoute("home")}
    />;
  } else if (route === "login") {
    screen = <LoginScreen onLogin={() => setRoute("home")} onBack={() => setRoute("home")} />;
  } else {
    // default = home; restaurants/stores/favorites/profile are stubbed to home for the demo
    screen = <HomeScreen
      cartCount={cartCount}
      onAddToCart={addToCart}
      onOpenStore={onOpenStore}
      onTab={onTab}
      onCart={onCart}
      onProfile={onProfile}
    />;
  }

  const showTabBar = route !== "login";
  const activeTab = ({ home: "home", restaurants: "restaurants", stores: "stores", favorites: "favorites", cart: "cart", profile: "profile" })[route] || "home";

  return (
    <React.Fragment>
      <IOSDevice width={402} height={874}>
        <div style={{ height: "100%", overflowY: "auto", scrollbarWidth: "none" }} className="no-scrollbar">
          {screen}
        </div>
        {showTabBar && <FwTabBar active={activeTab} onChange={onTab} cartCount={cartCount} />}
      </IOSDevice>
      <FlyToCart trigger={flyTick} image={flyState.image} source={flyState.source} />
    </React.Fragment>
  );
}

// Mount into #root once everything's loaded
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
