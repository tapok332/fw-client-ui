// HomeScreen.jsx — the main home view. Sticky glass header, hero carousel,
// category chips, featured stores, nearby stores, surprise box rail.

function HomeScreen({ cartCount, onAddToCart, onOpenStore, onTab, onCart, onProfile }) {
  const [slide, setSlide] = React.useState(0);
  const [activeCat, setActiveCat] = React.useState(null);

  React.useEffect(() => {
    const t = setInterval(() => setSlide(s => (s + 1) % HERO_SLIDES.length), 5000);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{ paddingBottom: 110, background: "hsl(var(--background))", minHeight: "100%" }}>
      <FwHeader cartCount={cartCount} onCart={onCart} onProfile={onProfile} />

      {/* Hero carousel */}
      <div style={{ padding: "16px 16px 0", position: "relative" }}>
        <FwHeroSlide
          image={HERO_SLIDES[slide].image}
          eyebrow={HERO_SLIDES[slide].eyebrow}
          headline={HERO_SLIDES[slide].headline}
          priceFrom={HERO_SLIDES[slide].priceFrom}
          retailPrice={HERO_SLIDES[slide].retailPrice}
          todayBadge={HERO_SLIDES[slide].todayBadge}
          ctaLabel="Забрати"
          onCta={() => onTab && onTab("restaurants")}
        />
        <div style={{
          position: "absolute", bottom: 12, left: 0, right: 0,
          display: "flex", justifyContent: "center", gap: 6,
        }}>
          {HERO_SLIDES.map((_, i) => (
            <button key={i} onClick={() => setSlide(i)} aria-label={`Слайд ${i+1}`}
              style={{
                width: i === slide ? 20 : 8, height: 8, borderRadius: 9999, border: 0,
                background: i === slide ? "hsl(var(--primary))" : "rgba(255,255,255,0.55)",
                cursor: "pointer", transition: "all 300ms ease",
              }} />
          ))}
        </div>
      </div>

      {/* Category chips */}
      <div style={{ padding: "16px 0 4px" }}>
        <div style={{ display: "flex", gap: 8, padding: "4px 16px", overflowX: "auto", scrollbarWidth: "none" }} className="no-scrollbar">
          <FwCategoryChip
            label="Усі"
            selected={activeCat === null}
            onClick={() => setActiveCat(null)}
          />
          {CATEGORIES.map(c => (
            <FwCategoryChip
              key={c.slug}
              label={c.label}
              icon={window[c.icon]}
              selected={activeCat === c.slug}
              onClick={() => setActiveCat(c.slug === activeCat ? null : c.slug)}
            />
          ))}
        </div>
      </div>

      {/* Featured stores */}
      <section style={{ paddingTop: 16 }}>
        <FwSectionHeader title="Популярні заклади" onAll={() => onTab && onTab("restaurants")} />
        <div style={{ display: "flex", gap: 14, padding: "8px 16px 16px", overflowX: "auto", scrollbarWidth: "none" }} className="no-scrollbar">
          {STORES.slice(0, 4).map(s => (
            <FwStoreCard key={s.id} store={s} onClick={() => onOpenStore && onOpenStore(s)} />
          ))}
        </div>
      </section>

      {/* Surprise boxes today */}
      <section style={{ paddingTop: 8 }}>
        <FwSectionHeader title="Сюрприз-бокси сьогодні" onAll={() => {}} />
        <div style={{ display: "flex", gap: 14, padding: "8px 16px 16px", overflowX: "auto", scrollbarWidth: "none" }} className="no-scrollbar">
          {BOXES.map(b => (
            <FwSurpriseBoxCard
              key={b.id}
              box={b}
              onClick={() => onOpenStore && onOpenStore(STORES.find(s => s.id === b.storeId) || STORES[0])}
              onAdd={onAddToCart}
            />
          ))}
        </div>
      </section>

      {/* Nearby stores */}
      <section style={{ paddingTop: 8 }}>
        <FwSectionHeader title="Заклади поблизу" onAll={() => onTab && onTab("stores")} />
        <div style={{ display: "flex", gap: 14, padding: "8px 16px 24px", overflowX: "auto", scrollbarWidth: "none" }} className="no-scrollbar">
          {NEARBY_STORES.map(s => (
            <FwStoreCard key={s.id} store={s} onClick={() => onOpenStore && onOpenStore(s)} />
          ))}
        </div>
      </section>
    </div>
  );
}

window.HomeScreen = HomeScreen;
