// CartScreen.jsx — cart with items, totals, eco-storytelling block, CTA. Empty state.

function CartScreen({ items, onBack, onInc, onDec, onRemove, onCheckout, onExplore }) {
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const fee = items.length ? 15 : 0;
  const total = subtotal + fee;
  const co2 = items.length * 0.7; // kg

  return (
    <div style={{ paddingBottom: 110, background: "hsl(var(--background))", minHeight: "100%" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "16px 16px 8px" }}>
        <button onClick={onBack} aria-label="Назад" style={{
          width: 36, height: 36, borderRadius: 9999, border: 0,
          background: "hsl(var(--muted))", color: "hsl(var(--foreground))",
          display: "grid", placeItems: "center", cursor: "pointer",
        }}><ChevLeft size={20} /></button>
        <h1 style={{ fontFamily: "var(--font-heading)", fontSize: 24, fontWeight: 700, margin: 0, color: "hsl(var(--foreground))" }}>
          Кошик
        </h1>
      </div>

      {items.length === 0 ? (
        // Empty state
        <div style={{ padding: 24, marginTop: 12 }}>
          <div style={{
            background: "hsl(var(--card))", borderRadius: 22, padding: 28,
            boxShadow: "var(--shadow-soft-md)", textAlign: "center",
            display: "flex", flexDirection: "column", alignItems: "center", gap: 14,
          }}>
            <div style={{
              width: 72, height: 72, borderRadius: 9999,
              background: "hsl(var(--muted))",
              display: "grid", placeItems: "center",
              color: "hsl(var(--muted-foreground))",
            }}>
              <ShoppingBag size={32} />
            </div>
            <h2 style={{ fontFamily: "var(--font-heading)", fontSize: 22, fontWeight: 600, margin: 0, color: "hsl(var(--foreground))" }}>
              Кошик порожній
            </h2>
            <p style={{ margin: 0, fontSize: 14, lineHeight: 1.55, color: "hsl(var(--muted-foreground))", maxWidth: 280 }}>
              Додайте сюрприз-бокси з улюблених закладів — і допоможіть планеті.
            </p>
            <FwButton size="lg" onClick={onExplore} leading={<ShoppingBag size={18} />}>
              Переглянути пропозиції
            </FwButton>
          </div>
        </div>
      ) : (
        <>
          {/* Items list */}
          <div style={{ margin: "12px 16px", padding: "0 16px",
                        background: "hsl(var(--card))", borderRadius: 18, boxShadow: "var(--shadow-soft-sm)" }}>
            {items.map(item => (
              <FwCartLine
                key={item.id}
                item={item}
                onInc={() => onInc(item.id)}
                onDec={() => onDec(item.id)}
                onRemove={() => onRemove(item.id)}
              />
            ))}
          </div>

          {/* Eco block — mission-first */}
          <div style={{ margin: "12px 16px", padding: "14px 18px",
                        background: "hsl(var(--primary) / 0.06)",
                        border: "1px solid hsl(var(--primary) / 0.15)",
                        borderRadius: 16, display: "flex", alignItems: "center", gap: 14 }}>
            <Leaf size={28} color="hsl(var(--primary))" />
            <div>
              <div style={{ fontWeight: 600, fontSize: 14, color: "hsl(var(--foreground))" }}>
                Цим замовленням ви зекономите {co2.toFixed(1)} кг CO₂
              </div>
              <div style={{ fontSize: 12, color: "hsl(var(--muted-foreground))", marginTop: 2 }}>
                Дякуємо, що рятуєте їжу 🌱
              </div>
            </div>
          </div>

          {/* Totals */}
          <div style={{ margin: "12px 16px 0", padding: 18,
                        background: "hsl(var(--card))", borderRadius: 18, boxShadow: "var(--shadow-soft-sm)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, color: "hsl(var(--muted-foreground))", marginBottom: 6,
                          fontVariantNumeric: "tabular-nums" }}>
              <span>Сума</span><span>{subtotal} ₴</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, color: "hsl(var(--muted-foreground))", marginBottom: 10,
                          fontVariantNumeric: "tabular-nums" }}>
              <span>Сервісний збір</span><span>{fee} ₴</span>
            </div>
            <FwDivider />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline",
                          marginTop: 12, fontVariantNumeric: "tabular-nums" }}>
              <span style={{ fontWeight: 600, fontSize: 16, color: "hsl(var(--foreground))" }}>До сплати</span>
              <span style={{ fontFamily: "var(--font-heading)", fontWeight: 700, fontSize: 22, color: "hsl(var(--primary))" }}>{total} ₴</span>
            </div>
          </div>

          {/* CTA */}
          <div style={{ padding: 16, paddingBottom: 28 }}>
            <FwButton fullWidth size="xl" onClick={onCheckout}>До оформлення</FwButton>
          </div>
        </>
      )}
    </div>
  );
}

window.CartScreen = CartScreen;
