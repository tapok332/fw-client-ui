// Data.jsx — mock data for the prototype. All Ukrainian copy where customer-facing.

// Photo URLs use Unsplash CDN (free, no auth). Hot-linked is fine for prototype.
const PHOTOS = {
  bakery1:    "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=600&q=70&auto=format",
  bakery2:    "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=600&q=70&auto=format",
  veggies:    "https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&q=70&auto=format",
  cafe:       "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=600&q=70&auto=format",
  groceries:  "https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&q=70&auto=format",
  sushi:      "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=600&q=70&auto=format",
  pizza:      "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&q=70&auto=format",
  salad:      "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&q=70&auto=format",
  dessert:    "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=600&q=70&auto=format",
  marketHero: "https://images.unsplash.com/photo-1488459716781-31db52582fe9?w=900&q=70&auto=format",
  bakerHero:  "https://images.unsplash.com/photo-1568254183919-78a4f43a2877?w=900&q=70&auto=format",
};

const STORES = [
  { id: "s1", name: "Bochka Bakery",       address: "вул. Лесі Українки, 12",   rating: 4.8, image: PHOTOS.bakery1, tag: "5 боксів" },
  { id: "s2", name: "Зелений Кошик",       address: "вул. Володимирська, 41",   rating: 4.6, image: PHOTOS.veggies, tag: "3 бокси" },
  { id: "s3", name: "Кав'ярня Дім",        address: "вул. Хрещатик, 22",        rating: 4.9, image: PHOTOS.cafe,    tag: "2 бокси" },
  { id: "s4", name: "Pizza Veterano",      address: "вул. Велика Васильківська, 60", rating: 4.7, image: PHOTOS.pizza },
  { id: "s5", name: "Sushi Master",        address: "вул. Саксаганського, 100",  rating: 4.5, image: PHOTOS.sushi },
];

const NEARBY_STORES = [
  { id: "n1", name: "Honey & Loaf",        address: "вул. Антоновича, 8 · 0.4 км",  rating: 4.7, image: PHOTOS.bakery2 },
  { id: "n2", name: "Сімейний Маркет",     address: "вул. Богдана Хмельницького, 32 · 0.8 км", rating: 4.4, image: PHOTOS.groceries },
  { id: "n3", name: "Green Bowl",          address: "вул. Жилянська, 14 · 1.1 км", rating: 4.6, image: PHOTOS.salad },
];

const CATEGORIES = [
  { slug: "bakery",     label: "Хліб",    icon: "Utensils" },
  { slug: "veggies",    label: "Овочі",   icon: "Sprout" },
  { slug: "cafe",       label: "Кав'ярні", icon: "Cart" },
  { slug: "groceries",  label: "Продукти", icon: "Store" },
  { slug: "desserts",   label: "Десерти", icon: "Heart" },
  { slug: "sushi",      label: "Суші",    icon: "Utensils" },
];

const BOXES = [
  { id: "b1", name: "Сюрприз від Bochka",   storeId: "s1", storeName: "Bochka Bakery",  image: PHOTOS.bakery1, discount: 60, price: 119, retailPrice: 299, pickupWindow: "17:30–19:00", distance: "0.8 км" },
  { id: "b2", name: "Овочевий кошик",       storeId: "s2", storeName: "Зелений Кошик",  image: PHOTOS.veggies, discount: 50, price: 149, retailPrice: 299, pickupWindow: "18:00–19:30", distance: "1.2 км" },
  { id: "b3", name: "Десертний сюрприз",    storeId: "s3", storeName: "Кав'ярня Дім",   image: PHOTOS.dessert, discount: 45, price: 99,  retailPrice: 180, pickupWindow: "19:00–20:00", distance: "0.4 км" },
  { id: "b4", name: "Sushi Box · 8 шт.",    storeId: "s5", storeName: "Sushi Master",   image: PHOTOS.sushi,   discount: 40, price: 219, retailPrice: 365, pickupWindow: "20:30–21:30", distance: "1.8 км" },
  { id: "b5", name: "Half-pizza Margherita",storeId: "s4", storeName: "Pizza Veterano", image: PHOTOS.pizza,   discount: 55, price: 129, retailPrice: 285, pickupWindow: "20:00–21:00", distance: "1.5 км" },
];

const HERO_SLIDES = [
  { id: 1, image: PHOTOS.bakerHero,  eyebrow: "Кав'ярня Дім · 0.4 км",       headline: "Свіже з ранку — за пів ціни",       priceFrom: 89,  retailPrice: 180, todayBadge: "Сьогодні · до -70%" },
  { id: 2, image: PHOTOS.marketHero, eyebrow: "Зелений Кошик · 1.2 км",      headline: "Овочевий кошик на сім'ю",          priceFrom: 149, retailPrice: 299, todayBadge: "Сьогодні · до -50%" },
  { id: 3, image: PHOTOS.dessert,    eyebrow: "Bochka Bakery · 0.8 км",      headline: "Десертний бокс на вечір",          priceFrom: 119, retailPrice: 240, todayBadge: "Сьогодні · до -50%" },
];

Object.assign(window, { PHOTOS, STORES, NEARBY_STORES, CATEGORIES, BOXES, HERO_SLIDES });
