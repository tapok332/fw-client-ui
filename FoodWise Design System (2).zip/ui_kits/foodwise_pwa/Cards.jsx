// Cards.jsx — StoreCard, SurpriseBoxCard, CategoryChip, HeroSlide, CartItemRow, OrderSummary

const PRIMARY_GREEN = "hsl(var(--primary))";
const MUTED        = "hsl(var(--muted-foreground))";
const FG           = "hsl(var(--foreground))";
const BORDER       = "hsl(var(--border))";

// Card surface — used as base for all product cards
const FwCard = ({ children, onClick, style = {} }) => (
  <div
    onClick={onClick}
    style={{
      background: "hsl(var(--card))",
      borderRadius: 24,
      overflow: "hidden",
      boxShadow: "var(--shadow-soft-md)",
      cursor: onClick ? "pointer" : "default",
      transition: "transform 200ms cubic-bezier(.23,1,.32,1), box-shadow 200ms cubic-bezier(.23,1,.32,1)",
      ...style,
    }}
  >
    {children}
  </div>
);

// Category chip — used in horizontal scrollers
const FwCategoryChip = ({ label, icon: Icon, selected, onClick }) => (
  <button
    onClick={onClick}
    aria-pressed={selected}
    style={{
      display: "inline-flex", alignItems: "center", gap: 6, whiteSpace: "nowrap",
      height: 36, padding: "0 14px", borderRadius: 9999,
      border: selected ? 0 : `1px solid ${BORDER}`,
      background: selected ? PRIMARY_GREEN : "transparent",
      color: selected ? "#fff" : FG,
      fontFamily: "var(--font-body)", fontSize: 13, fontWeight: 500,
      cursor: "pointer", flexShrink: 0,
      transition: "background-color 200ms ease, color 200ms ease",
    }}
  >
    {Icon && <Icon size={14} />}
    {label}
  </button>
);

// Store/restaurant card — w-64
const FwStoreCard = ({ store, onClick }) => (
  <FwCard onClick={onClick} style={{ width: 220, flexShrink: 0 }}>
    <div style={{ position: "relative", height: 124, background: `url(${store.image}) center/cover` }}>
      {store.rating > 0 && (
        <FwGlassChip style={{ position: "absolute", top: 10, right: 10 }}>
          <Star size={12} color="hsl(45 95% 55%)" style={{ fill: "hsl(45 95% 55%)" }} />
          <span style={{ marginLeft: 2 }}>{store.rating.toFixed(1)}</span>
        </FwGlassChip>
      )}
      {store.tag && (
        <FwGlassChip style={{ position: "absolute", top: 10, left: 10, color: PRIMARY_GREEN }}>
          {store.tag}
        </FwGlassChip>
      )}
    </div>
    <div style={{ padding: 14 }}>
      <div style={{ fontFamily: "var(--font-body)", fontWeight: 600, fontSize: 15, color: FG, marginBottom: 6,
                    overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {store.name}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: MUTED }}>
        <MapPin size={13} color="hsl(var(--primary) / 0.7)" />
        <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{store.address}</span>
      </div>
    </div>
  </FwCard>
);

// Surprise box card — the hero product card
const FwSurpriseBoxCard = ({ box, onClick, onAdd }) => (
  <FwCard onClick={onClick} style={{ width: 220, flexShrink: 0 }}>
    <div style={{ position: "relative", height: 140, background: `url(${box.image}) center/cover` }}>
      {box.discount && (
        <span style={{
          position: "absolute", top: 10, left: 10,
          background: "hsl(var(--accent))", color: "#fff",
          padding: "5px 11px", borderRadius: 9999,
          fontSize: 11, fontWeight: 600,
        }}>-{box.discount}%</span>
      )}
      <button
        onClick={(e) => {
          e.stopPropagation();
          const r = e.currentTarget.getBoundingClientRect();
          const source = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
          onAdd && onAdd(box, source);
        }}
        aria-label={`Додати ${box.name}`}
        style={{
          position: "absolute", bottom: 10, right: 10,
          width: 36, height: 36, borderRadius: 9999,
          background: PRIMARY_GREEN, color: "#fff", border: 0,
          display: "grid", placeItems: "center", cursor: "pointer",
          boxShadow: "0 2px 8px hsla(145,63%,30%,0.4)",
          transition: "transform 120ms ease",
        }}
        onMouseDown={(e) => e.currentTarget.style.transform = "scale(0.85)"}
        onMouseUp={(e) => e.currentTarget.style.transform = "scale(1)"}
        onMouseLeave={(e) => e.currentTarget.style.transform = "scale(1)"}
      >
        <Plus size={18} />
      </button>
    </div>
    <div style={{ padding: 14 }}>
      <div style={{ fontWeight: 600, fontSize: 15, color: FG, marginBottom: 6,
                    overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {box.name}
      </div>
      {box.price != null && (
        <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginBottom: 8,
                      fontVariantNumeric: "tabular-nums" }}>
          <span style={{ fontFamily: "var(--font-heading)", fontWeight: 700, fontSize: 17, color: PRIMARY_GREEN }}>
            {box.price} ₴
          </span>
          {box.retailPrice && box.retailPrice > box.price && (
            <span style={{ fontSize: 12, color: MUTED, textDecoration: "line-through" }}>
              {box.retailPrice} ₴
            </span>
          )}
        </div>
      )}
      <div style={{ display: "flex", gap: 10, fontSize: 11, color: MUTED, fontVariantNumeric: "tabular-nums" }}>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
          <Clock size={12} color="hsl(var(--primary) / 0.7)" />
          {box.pickupWindow}
        </span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
          <MapPin size={12} color="hsl(var(--primary) / 0.7)" />
          {box.distance}
        </span>
      </div>
    </div>
  </FwCard>
);

// Hero slide — richer composition (eyebrow + headline + price + today badge + floating leaf)
const FwHeroSlide = ({ image, eyebrow, headline, priceFrom, retailPrice, todayBadge, ctaLabel = "Забрати", onCta }) => (
  <div style={{
    position: "relative", borderRadius: 22, overflow: "hidden",
    height: 240, background: `url(${image}) center/cover`,
  }}>
    {/* Bottom→top scrim */}
    <div style={{ position: "absolute", inset: 0,
                  background: "linear-gradient(180deg, rgba(15,30,18,0) 0%, rgba(15,30,18,0) 30%, rgba(15,30,18,0.55) 65%, rgba(15,30,18,0.95) 100%)" }} />
    {/* Left-side scrim — keeps headline column dark */}
    <div style={{ position: "absolute", inset: 0,
                  background: "linear-gradient(90deg, rgba(15,30,18,0.55) 0%, rgba(15,30,18,0.15) 55%, rgba(15,30,18,0) 100%)" }} />

    {/* Floating leaf — decorative */}
    <svg width="72" height="72" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.18)" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"
         style={{ position: "absolute", top: 14, right: 18, animation: "fwLeafFloat 6s ease-in-out infinite" }}>
      <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19.2 2.96a1 1 0 0 1 1.8.4 28.3 28.3 0 0 1-3.2 14.06A7 7 0 0 1 11 20Z" />
      <path d="M2 21c0-3 1.85-5.36 5.08-6" />
    </svg>

    {/* "Today" pill — top-left */}
    {todayBadge && (
      <div style={{
        position: "absolute", top: 14, left: 14,
        display: "inline-flex", alignItems: "center", gap: 6,
        background: "hsl(var(--accent))", color: "#fff",
        padding: "6px 12px", borderRadius: 9999,
        fontSize: 11, fontWeight: 600, letterSpacing: "0.02em",
        boxShadow: "0 4px 14px hsla(32,90%,55%,0.4)",
      }}>
        <span style={{ width: 6, height: 6, borderRadius: 9999, background: "#fff",
                       boxShadow: "0 0 0 4px rgba(255,255,255,0.3)" }} />
        {todayBadge}
      </div>
    )}

    {/* Headline block bottom-left */}
    <div style={{ position: "absolute", left: 18, right: 18, bottom: 56, color: "#fff" }}>
      {eyebrow && (
        <div style={{ fontFamily: "var(--font-body)", fontSize: 10, fontWeight: 600,
                      textTransform: "uppercase", letterSpacing: "0.1em",
                      color: "hsl(40 60% 88%)", opacity: 0.9, marginBottom: 6 }}>
          {eyebrow}
        </div>
      )}
      <h1 style={{
        margin: "0 0 6px", color: "#fff",
        fontFamily: "var(--font-heading)", fontWeight: 700, fontSize: 24, lineHeight: 1.05,
        letterSpacing: "-0.01em", textWrap: "balance",
        textShadow: "0 2px 18px rgba(0,0,0,0.75), 0 1px 4px rgba(0,0,0,0.7)",
        maxWidth: "70%",
      }}>{headline}</h1>
      {priceFrom != null && (
        <div style={{ display: "flex", alignItems: "baseline", gap: 8,
                      fontVariantNumeric: "tabular-nums",
                      textShadow: "0 1px 4px rgba(0,0,0,0.5)" }}>
          <span style={{ fontFamily: "var(--font-heading)", fontWeight: 600, fontSize: 16, color: "hsl(32 90% 70%)" }}>
            від {priceFrom} ₴
          </span>
          {retailPrice && (
            <span style={{ fontSize: 12, color: "rgba(255,255,255,0.65)", textDecoration: "line-through" }}>
              {retailPrice} ₴
            </span>
          )}
        </div>
      )}
    </div>

    {/* CTA bottom-right */}
    <button onClick={onCta} style={{
      position: "absolute", bottom: 50, right: 16,
      background: "hsl(var(--primary))", color: "#fff", border: 0,
      padding: "12px 18px", borderRadius: 14,
      fontFamily: "var(--font-body)", fontWeight: 500, fontSize: 14,
      cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6,
      boxShadow: "0 6px 20px hsla(145,63%,30%,0.5)",
    }}>
      {ctaLabel}
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
           strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M5 12h14" /><path d="m12 5 7 7-7 7" />
      </svg>
    </button>
  </div>
);

// Cart-line item
const FwCartLine = ({ item, onInc, onDec, onRemove }) => (
  <div style={{ display: "flex", gap: 12, padding: "14px 0", borderBottom: `1px solid ${BORDER}` }}>
    <div style={{ width: 64, height: 64, borderRadius: 12, background: `url(${item.image}) center/cover`, flexShrink: 0 }} />
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontWeight: 600, fontSize: 14, color: FG, marginBottom: 2,
                    overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {item.name}
      </div>
      <div style={{ fontSize: 11, color: MUTED, marginBottom: 8 }}>{item.storeName}</div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <button onClick={onDec} aria-label="Зменшити"
                  style={{ width: 28, height: 28, borderRadius: 9999, border: `1px solid ${BORDER}`, background: "transparent", display: "grid", placeItems: "center", cursor: "pointer", color: FG }}>
            <Minus size={14} />
          </button>
          <span style={{ minWidth: 20, textAlign: "center", fontSize: 14, fontWeight: 500, fontVariantNumeric: "tabular-nums" }}>{item.qty}</span>
          <button onClick={onInc} aria-label="Додати"
                  style={{ width: 28, height: 28, borderRadius: 9999, border: 0, background: PRIMARY_GREEN, color: "#fff", display: "grid", placeItems: "center", cursor: "pointer" }}>
            <Plus size={14} />
          </button>
        </div>
        <span style={{ fontWeight: 700, fontSize: 14, color: FG, fontVariantNumeric: "tabular-nums" }}>
          {(item.price * item.qty)} ₴
        </span>
      </div>
    </div>
  </div>
);

Object.assign(window, { FwCard, FwCategoryChip, FwStoreCard, FwSurpriseBoxCard, FwHeroSlide, FwCartLine });
